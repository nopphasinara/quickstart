SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `listing_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(1, 'Sapiente voluptas enim', 'quasi-provident-expedita-quia-natus-in-culpa', 'Laborum sunt est quasi veritatis dolores nobis. Voluptas natus ut voluptatem voluptatem vero aut qui. In saepe perferendis minus totam et officiis hic veritatis. Harum ut ut laboriosam neque ipsam.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(2, 'Dolor qui', 'est-velit-qui-voluptatum-earum-ab-dolores-fugiat', 'Iure debitis itaque repudiandae dolor debitis sint eos. Tempore delectus dignissimos autem consequuntur. Dolorum nobis similique necessitatibus suscipit. Et corporis illum ut alias expedita nam.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(3, 'Commodi dignissimos velit', 'rem-et-sunt-enim-sint-et-perspiciatis-omnis', 'Sed veritatis nisi molestiae. Nesciunt totam qui adipisci est voluptatem.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(4, 'Qui unde', 'impedit-in-rem-animi-voluptates-at', 'Dolores sunt molestiae dolorem quod sint. Enim aliquid voluptas molestias illum.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(5, 'Maiores nobis', 'laudantium-esse-rerum-laboriosam-at-vero-non', 'Quam ut qui voluptatum eveniet qui impedit ea. Fuga et voluptas nostrum velit quae aut. Ratione deleniti culpa sunt omnis. Quo a quas dolore quia sint possimus.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(6, 'Non ea nihil', 'aperiam-ipsam-veritatis-quisquam-repudiandae-et-qui-qui', 'Perferendis nam fuga ea voluptatem molestiae quia culpa. Qui corrupti animi iste tempora ea sed tempora dolor.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(7, 'Et error placeat', 'aut-recusandae-ipsa-eos-nulla-quia-unde', 'Perspiciatis nihil quia recusandae recusandae hic eaque. Iure iure sapiente nemo expedita blanditiis minima. Est id non dolor ad consequuntur. Labore ducimus quia nam itaque aliquid possimus beatae.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(8, 'Id quaerat dolore', 'id-cupiditate-aliquid-minima-qui', 'Molestiae eum eos eos similique. Explicabo mollitia dolor aut corporis officiis. Voluptatem perspiciatis dolores accusamus vero animi numquam in itaque. Et repellat numquam id ea porro.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(9, 'Accusamus exercitationem consequatur', 'facilis-sint-quisquam-aut-eum-ut-quisquam', 'Dolorum porro vitae occaecati ex. Dolor ut sit vel occaecati qui repellendus. Doloribus id at omnis dolor doloremque nihil ea.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(10, 'Consectetur ex optio', 'ut-consequuntur-est-voluptas-sequi', 'Non consectetur possimus porro. Dolorum at possimus soluta eaque. Qui fugit qui et et vero consequuntur. Voluptatem corporis officiis veritatis a omnis laboriosam.', '2018-04-22 05:28:29', '2018-04-22 05:28:29');
INSERT INTO `listing_types` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES(12, 'About Us', 'about-us', 'asdasdas', '2018-04-22 05:58:37', '2018-04-22 05:58:37');

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES(4, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES(5, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES(6, '2018_04_22_122135_create_listing_types_table', 1);

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


ALTER TABLE `listing_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `listing_types_slug_unique` (`slug`);

ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);


ALTER TABLE `listing_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
